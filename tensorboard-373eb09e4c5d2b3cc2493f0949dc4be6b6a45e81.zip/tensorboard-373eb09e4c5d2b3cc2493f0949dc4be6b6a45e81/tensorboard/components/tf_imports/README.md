This file acts as import routers for third party javascript libraries,
e.g. Plottable and D3.
