Developers can extend TensorBoard by building a plugin. Please see [the relevant documentation](https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md).
