# How to start

1. copy JAR package from $REPO/out/$OS/RelWithDebInfo/java/build/libs/onnxruntime-extensions-${VERSION}.jar into app/libs folder.
2. build and run this java project.
