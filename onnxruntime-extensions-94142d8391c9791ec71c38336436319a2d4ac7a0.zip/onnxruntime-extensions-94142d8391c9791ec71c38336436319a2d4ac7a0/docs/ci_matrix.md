### CI Build Matrix

The matrix below lists the versions of individual dependencies of onxxruntime-extensions. These are the configurations that are routinely and extensively verified by our CI.

Python | 3.7 | 3.8 | 3.9 | 3.10
---|---|---|---|---
Onnxruntime |1.11.0 (Mar 26, 2022) |1.12.1 (Aug 4, 2022) |1.13.1(Oct 24, 2022)  |1.14.1 (Mar 2, 2023)
