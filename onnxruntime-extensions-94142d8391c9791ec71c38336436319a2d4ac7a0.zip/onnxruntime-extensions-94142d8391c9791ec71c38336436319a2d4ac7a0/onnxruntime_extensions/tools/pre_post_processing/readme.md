Documentation was generated with pdoc3 (`pip install pdoc3`).
From the parent directory:
  `python -m pdoc pdoc pre_post_processing -o ./pre_post_processing/docs --filter pre_post_processing`

This was just a quick way to get some initial docs.
There are probably better python doc generation tools in the CI that can be used.

It's not ideal in that there are no links between the different md files
   e.g. the doc for the base Step class mentions the derived classes but doesn't provide links to read their doc.

However it does seem to document each class fairly well.
