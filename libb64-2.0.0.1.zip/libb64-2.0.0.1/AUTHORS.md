﻿libb64: Base64 Encoding/Decoding Routines
======================================

Authors
-------

Chris Venter	chris.venter@gmail.com	http://controlaltfire.com

Contributors
------------

Name               | Contact / Changes
-------------------|-------------------------------------------------------------
Mario Rugiero      |
Shlok Datye        |
Peter K. Lee       |
Stefan Gänsler     | https://github.com/libb64/libb64/commits?author=stefan-muc
Thilo Schulz       | https://github.com/libb64/libb64/commits?author=thiloschulz

Patches by
------------
Name               | Contact / Changes
-------------------|-------------------------------------------------------------
Harry Rostovtsev   | http://sourceforge.net/p/libb64/bugs/1/#8706
Jakub Wilk         | http://sourceforge.net/p/libb64/bugs/2/#4d16
